<?php
$con=mysqli_connect("127.0.0.1","thilanka","abc123");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
} else {
  echo "successfully connected to MySQL.";
}
echo("<br>");

// // Create database websys_shop
// $sql1="CREATE DATABASE websys_shop";
// if (mysqli_query($con,$sql1)) {
//   echo "Database websys_shop created successfully";
// } else {
//   echo "Error creating database: " . mysqli_error($con);
// }
// echo("<br>");

// // Create a table: customers
// $sql2="CREATE TABLE websys_shop.customers (id INT AUTO_INCREMENT PRIMARY KEY, fname VARCHAR(255), lname VARCHAR(255));";
// if (mysqli_query($con,$sql2)) {
//   echo "Created customers table successfully";
// } else {
//   echo "Error creating customers table: " . mysqli_error($con);
// }
// echo("<br>");

// // Create table products
// $sql3="CREATE TABLE websys_shop.products (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), price DECIMAL(10.2));";
// if (mysqli_query($con,$sql3)) {
//   echo "Created products table successfully";
// } else {
//   echo "Error creating products table: " . mysqli_error($con);
// }
// echo("<br>");

// Drop customers
// $sql4="DROP TABLE websys_shop.customers;";
// if (mysqli_query($con,$sql4)) {
//   echo "Dropped customers table successfully";
// } else {
//   echo "Error dropping customers table: " . mysqli_error($con);
// }
// echo("<br>");


// // Drop products
// $sql5="DROP TABLE websys_shop.products;";
// if (mysqli_query($con,$sql5)) {
//   echo "Dropped products table successfully";
// } else {
//   echo "Error creating products table: " . mysqli_error($con);
// }
// echo("<br>");

// insert values into customer table

// $sql6="INSERT INTO websys_shop.customers (fname, lname) VALUES('Johnny','Jones');";
// if (mysqli_query($con,$sql6)) {
//   echo "Inserted values into customer table successfully";
// } else {
//   echo "Error inserting to table customers: " . mysqli_error($con);
// }
// echo("<br>");


?>